<?php /* C:\xampp\htdocs\laravel\blog_demo\resources\views/post/list.blade.php */ ?>
<?php $__env->startSection('title', 'Danh sách công viêc'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h2>Danh sách công viêc</h2>
        </div>
        <div class="col-12">
            <?php if(Session::has('success')): ?>
                <p class="text-success">
                    <i class="fa fa-check" aria-hidden="true"></i>
                    <?php echo e(Session::get('success')); ?>

                </p>
            <?php endif; ?>
        </div>
        <div class="col-md-12">
            <table class="table table-striped">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Tên công việc</th>
                    <th scope="col">Nội dung</th>
                    <th scope="col">Ảnh</th>
                    <th scope="col">Ngày hết hạn</th>
                    <th></th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e(++$key); ?></th>
                    <td><?php echo e($post->title); ?></td>
                    <td><?php echo e($post->content); ?></td>
                    <td>
                        <?php if($post->image): ?>
                        <img src="<?php echo e(asset('storage/'.$post->image)); ?>" alt="" style="width: 200px; height: 200px">
                        <?php else: ?>
                            <?php echo e('Chưa có ảnh'); ?>

                        <?php endif; ?>
                    </td>
                    <td><?php echo e($post->date); ?></td>
                    <td><a href="<?php echo e(route('posts.edit', $post->id)); ?>">sửa</a></td>
                    <td><a href="<?php echo e(route('posts.destroy',$post->id)); ?>" class="text-danger" onclick="return confirm('Bạn chắc chắn muốn xóa?')">xóa</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <a href="<?php echo e(route('post.create')); ?>" class="btn btn-primary">Thêm mới</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>